import React from 'react';
import './App.css';
import QuizComponent from './components/QuizComponent';

function App() {


  return (
    <div className="App">
   
    <QuizComponent />

    </div>
  );
}

export default App;
