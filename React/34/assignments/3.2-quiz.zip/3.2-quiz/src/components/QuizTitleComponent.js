
import React from 'react';


const quizInputComponent = (props) =>  <h1 className={props.class}>{props.title}</h1> ;


export default quizInputComponent;